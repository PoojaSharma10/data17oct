
public class Person extends Thread{
    synchronized public void run()
    {}
    static private int age;
    private String  name;
    
	public Person() {
		this.age=18;
		this.name="Not Available";
	}
	static public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	static void thisInStatic(){
	    new Object(){
	        Object instance = this;
	    };
	}
}
